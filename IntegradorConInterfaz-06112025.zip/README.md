# Integrador-POO
Realizamos un sistema de biblioteca sencillo, utilizando el lenguaje JAVA y la herramienta Bluej, con las consignas dadas en la asignatura "Programación Orientada a Objetos".
